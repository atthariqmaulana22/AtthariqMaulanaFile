<?php 
 // panggil file connect database
include 'koneksi.php';
 
error_reporting(0);
 
session_start();
 // cek apakah di dalam session ada username ? 
if (isset($_SESSION['email'])) {
   header("Location: index.html");
   echo "berhasil login";
}
 
if (isset($_POST['Login'])) {
  // ambil data dari input email dan input password lalu masukan ke variabel $email dan $password
   $email = $_POST['email'];
   $password = md5($_POST['password']);

 // query sql cek apakah ada user dengan nama dan password yang sama 
   $sql = "SELECT * FROM user WHERE email='$email' AND password='$password'";

// eksekusi $sql tadi , database cek
   $result = mysqli_query($koneksi, $sql);

// apabila berhasil login mengarah ke home
   if ($result->num_rows > 0) {
      // pindah ke index.php
      header("Location: index.html");
   } else {
      $error[] = 'Incorrect email or password!';
   }
}
 
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Login Page</title>
   <link rel="stylesheet" href="login.css">

</head>

<body>  
    <div class="container">
        <div class="login">
            <form method="post">
               <h2>Login</h2>
               <hr>
               <?php
               if(isset($error)){
                  foreach($error as $error){
                     echo '<span class="error-msg">'.$error.'</span>';
                  };
               };
               ?>
               <br>
<br> 
<!-- ini life hack spasi css -->
<br>
<br>
<br>    
               <br>
               <label for="">Email</label>
               <input type="text" name="email" placeholder="example@gmail.com" required>
               <label for="">Password</label>
               <input type="password" name="password" placeholder="Password" required>
               <input type="submit" name="Login" value="Login" class="form-btn">
               <p>Don't have an account? <a href="register.php">Register now</a></p>
            </form>
        </div>
        <div class="right">
            <img src="telkom.jpg" alt="">
        </div>
    </div>
</body>


</html>