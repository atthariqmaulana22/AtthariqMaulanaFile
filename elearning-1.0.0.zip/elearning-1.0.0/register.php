<?php 
 // manggil koneksi
include 'koneksi.php';
 
error_reporting(0);
 
session_start();
 // kalau misalnya sudah login 
if (isset($_SESSION['email'])) {
    header("Location: dashboard.php");
}


 
if (isset($_POST['register'])) {

   // ambil data dari form input username, email, password, cpassword
   $username = $_POST['username'];
   $email = $_POST['email'];
   $password = md5($_POST['password']);
   $cpassword = md5($_POST['cpassword']);
 
   $sql = "SELECT * FROM user WHERE email='$email' && password='$password'";
   $result = mysqli_query($koneksi, $sql);

   if(mysqli_num_rows($result) > 0 ){
      $error[] = 'User already exist!';
   } else {
      if($password != $cpassword){
         $error[] = 'Password not matched!';
      } else {
         $sql = "INSERT INTO user (username, email, password) VALUES ('$username', '$email', '$password')";
         $result = mysqli_query($koneksi, $sql);
         header("Location: login.php");

      }
   }
}; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Register Page</title>
   <link rel="stylesheet" href="register.css">

</head>

<body>  
    <div class="container">
        <div class="register">
            <form method="post" action="">
               <h2>Register</h2>
               <hr>
               <?php
               if(isset($error)){
                  foreach($error as $error){
                     echo '<span class="error-msg">'.$error.'</span>';
                  };
               };
               ?>
               <br>
               <label for=""> Username </label>
               <input type="text" name="username" required placeholder="enter your name" required>
               <label for=""> Email </label>
               <input type="email" name="email" required placeholder="enter your email" required>
               <label for=""> Password </label>
               <input type="password" name="password" required placeholder="enter your password" required>
               <label for=""> Confirm Your Password </label>
               <input type="password" name="cpassword" required placeholder="confirm your password" required>
               <input type="submit" name="register" value="Register" class="form-btn">
               <p>Already have an account? <a href="login.php">Login now</a></p>
            </form>
        </div>
    </div>
</body>


</html>